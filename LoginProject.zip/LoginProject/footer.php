</div>
</body>
</html>

<script src="JS/script.ks"></script>